#!/bin/bash
> /var/spool/mail/root
/usr/sbin/ntpdate pool.ntp.org > /dev/null 2>&1
